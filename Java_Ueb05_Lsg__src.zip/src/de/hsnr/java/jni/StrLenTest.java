package de.hsnr.java.jni;

public class StrLenTest {

	public static void main(String[] args) {
		String s1 = "Hallo";
		String s2 = "s2";
		String s3 = "|s3| + ? = 13";
		
		String[] arr = { s1, s2, s3 };
		
		System.out.println("StrLenTest");
		for (int i = 0; i < arr.length; i++) {
			System.out.println("s[" + i + "] = " + arr[i]);
			int len = StrLen.strlen(arr[i]);
			System.out.println("   -> strlen = " + len);
		}
	}
}
