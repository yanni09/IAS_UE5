package de.hsnr.java.jni;

public class StrLen {

	public static native int strlen(String s);
	
	static {
		System.out.println("de.hsnr.java.jni.StrLen: try loading Library 'strlen'.");
		
		System.loadLibrary( "JNI_Strlen" );
		
		System.out.println("de.hsnr.java.jni.StrLen: loaded Library 'strlen'.");
	}
}
